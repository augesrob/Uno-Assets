<h1 class="text-2xl font-bold mb-2">Spectating Lobby #<?= (int)$lobbyId ?></h1>
<p class="text-slate-300">Live view coming soon. Spectators will see moves and chat in real-time.</p>
