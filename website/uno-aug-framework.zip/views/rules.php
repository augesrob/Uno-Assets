<h1 class="text-2xl font-bold mb-3">Classic UNO Rules</h1>
<p class="text-slate-300">We follow official classic rules for now. Custom rules & modes coming later.</p>
<p class="mt-2"><a class="underline" href="https://playjoy.com/en/uno/rules/" target="_blank">Read full rules</a></p>
