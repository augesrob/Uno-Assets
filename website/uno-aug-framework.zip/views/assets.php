<h1 class="text-2xl font-bold mb-4">Assets</h1>
<p class="mb-2">Your webhost will mirror the contents of the assets repository:</p>
<a class="underline" target="_blank" href="<?= htmlspecialchars($assetsUrl) ?>"><?= htmlspecialchars($assetsUrl) ?></a>
